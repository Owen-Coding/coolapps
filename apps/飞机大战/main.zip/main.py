import pygame,time,random
from tkinter import *
pygame.init()
WIDTH = 480
HEIGHT = 700
FPS = 30
running = True
gameover = False
score = 0
level = 1
boss = False
font = pygame.font.Font("./font/font.ttf",40)
font2 = pygame.font.Font("./font/font.ttf",50)
boss_timer = 0
#Volume_set
bgmusic_volume = 0.5
upgrade_volume = 0.5
#Sound
pygame.mixer.music.load("./sound/game_music.ogg")
pygame.mixer.music.set_volume(bgmusic_volume)
upgrade = pygame.mixer.Sound("./sound/upgrade.wav")
upgrade.set_volume(upgrade_volume)

try:
    with open("best_score.txt","r") as opened:
        best_score = int(opened.read())
except:
    best_score = 0

print(best_score)

all_PlayerBullet = pygame.sprite.Group()
all_enemys = pygame.sprite.Group()
all_EnemyBullet = pygame.sprite.Group()
class System():
    def __init__(self):
        self.bg = pygame.image.load("./images/background.png")
        self.make_enemys_wait = random.random() * 3
        self.make_enemys_timer = time.time()
        self.make_enemys_wait_mu = 3
        self.running = True
        self.botton1 = pygame.image.load("./images/again.png")
        self.botton1R = self.botton1.get_rect()
        self.botton1R.center = (240, 500)
        self.botton2 = pygame.image.load("./images/gameover.png")
        self.botton2R = self.botton1.get_rect()
        self.botton2R.center = (240, 550)
        self.settingImage = pygame.transform.scale(pygame.image.load("./images/settings.png"),(80,80))
        self.settingRect = self.settingImage.get_rect()
        self.settingRect.center = (430,50)
    def blitBackground(self,screen):
        screen.blit(self.bg,(0,0))
    def make_enemy1(self):
        if time.time() - self.make_enemys_timer >= self.make_enemys_wait:
            self.enemy = Enemy1()
            all_enemys.add(self.enemy)
            self.make_enemys_wait = random.random() * self.make_enemys_wait_mu
            self.make_enemys_timer = time.time()
    def make_enemy2(self):
        if time.time() - self.make_enemys_timer >= self.make_enemys_wait:
            self.enemy = Enemy2()
            all_enemys.add(self.enemy)
            self.make_enemys_wait = random.random() * self.make_enemys_wait_mu
            self.make_enemys_timer = time.time()
    def make_enemy3(self):
        if time.time() - self.make_enemys_timer >= self.make_enemys_wait:
            self.enemy = Enemy3()
            all_enemys.add(self.enemy)
            self.make_enemys_wait = random.random() * self.make_enemys_wait_mu
            self.make_enemys_timer = time.time()
    def main_controls(self):
        global gameover,screen,all_PlayerBullet,all_EnemyBullet,all_enemys,player,score,best_score
        self.running = True
        if score > best_score:
            with open("best_score.txt","w") as self.opened:
                self.opened.write(str(score))
                best_score = score

        self.bscore = font.render("Your Best:" + str(best_score), True, (100, 100, 100))
        self.bscoreR = self.bscore.get_rect()
        self.bscoreR.x,self.bscoreR.y = 10,10
        self.score = font.render("Your Score:" + str(score), True, (100, 100, 100))
        self.scoreR = self.score.get_rect()
        self.scoreR.center = (240,450)
        if gameover == True:
            while self.running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if self.botton1R.collidepoint(event.pos):
                            all_PlayerBullet.empty()
                            all_enemys.empty()
                            all_EnemyBullet.empty()
                            score = 0
                            player.__init__()
                            gameover = False
                            self.running = False
                            self.make_enemys_wait_mu = 3
                        elif self.botton2R.collidepoint(event.pos):
                            pygame.quit()
                            exit()
                        elif self.settingRect.collidepoint(event.pos):
                            self.open_settings()
                self.blitBackground(screen)
                screen.blit(self.botton1,self.botton1R)
                screen.blit(self.botton2, self.botton2R)
                screen.blit(self.bscore, self.bscoreR)
                screen.blit(self.score, self.scoreR)
                screen.blit(self.settingImage,self.settingRect)
                pygame.display.update()
    def blit_score(self,screen,score):
        scoreSurface = font.render("Score:" + str(score), True, (255, 255, 255))
        screen.blit(scoreSurface, (10, 10))
    def set_level(self):
        global score,level
        self.old_level = level
        if score <= 2000:
            level = 1
        elif score <= 5000:
            level = 2
        elif score <= 10000:
            level = 3
        elif score <= 15000:
            level = 4
        elif score <= 25000:
            level = 5
        else:
            level = int((score-25000)/10000) + 5
        return self.old_level,level
    def open_settings(self):
        self.tk = Tk()
        self.tk.geometry("400x500")
        self.tk.resizable(False, True)
        self.tk.title("Settings")
        self.bgmusic_result = DoubleVar()
        self.upgrade_result = DoubleVar()
        #title
        self.title_text = Label(self.tk,text="Settings",fg="red",bg="lightyellow")
        self.title_text.grid(row=1,column=1)
        # bgMusic Volume
        self.bgmusic_text = Label(self.tk, relief=RAISED, text="Background Music Volume:")
        self.bgmusic_text.grid(row=2, column=1)
        self.bgmusic_scale = Scale(self.tk, length=300, variable=self.bgmusic_result, from_=0, to=100, orient=HORIZONTAL)
        self.bgmusic_scale.grid(row=2,column=2)
        # Upgrade Volume
        self.upgrade_text = Label(self.tk, relief=RAISED, text="Upgrade Volume:")
        self.upgrade_text.grid(row=3, column=1)
        self.upgrade_scale = Scale(self.tk, length=300, variable=self.upgrade_result, from_=0, to=100, orient=HORIZONTAL)
        self.upgrade_scale.grid(row=3, column=2)
        #Submit Button
        ok = Button(self.tk,text="Submit",command=self.set_volume)
        ok.grid(row=100,column=1)
        self.tk.mainloop()
    def set_volume(self):
        global bgmusic_volume,upgrade_volume
        bgmusic_volume = self.bgmusic_result.get()/100
        upgrade_volume = self.upgrade_result.get()/100
        pygame.mixer.music.set_volume(bgmusic_volume)
        upgrade.set_volume(upgrade_volume)
class PlayerBullet(pygame.sprite.Sprite):
    def __init__(self,sprite):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("./images/bullet1.png")
        self.rect = self.image.get_rect()
        self.rect.center = (sprite.rect.centerx,sprite.rect.y)
    def update(self):
        self.rect.y -= 15
        if self.rect.bottom <= 0:
            all_PlayerBullet.remove(self)

class EnemyBullet(pygame.sprite.Sprite):
    def __init__(self,sprite):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("./images/bullet2.png")
        self.rect = self.image.get_rect()
        self.rect.center = (sprite.rect.centerx,sprite.rect.y)
    def update(self):
        self.rect.y += 15
        if self.rect.bottom <= 0:
            all_PlayerBullet.remove(self)


class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image1 = pygame.image.load("./images/me1.png")
        self.image2 = pygame.image.load("./images/me2.png")
        self.image = self.image1
        self.rect = self.image.get_rect()
        self.rect.center = (240,600)
        self.imageNum = 1
        self.mode_timer = time.time()
        self.attack_timer = time.time()
        self.boom = False
        self.boomI1 = pygame.image.load("./images/me_destroy_1.png")
        self.boomI2 = pygame.image.load("./images/me_destroy_2.png")
        self.boomI3 = pygame.image.load("./images/me_destroy_3.png")
        self.boomI4 = pygame.image.load("./images/me_destroy_4.png")
        self.boomImages = [self.boomI1,self.boomI2,self.boomI3,self.boomI4]
        self.boomImage_index = 0
        self.boom_timer = time.time()
    def draw(self,screen):
        screen.blit(self.image,self.rect)
    def update(self):
        self.keyboard = pygame.key.get_pressed()
        if self.keyboard[pygame.K_LEFT] or self.keyboard[pygame.K_a]:
            self.rect.x -= 7
            if self.rect.left < 0:
                self.rect.left = 0
        elif self.keyboard[pygame.K_RIGHT] or self.keyboard[pygame.K_d]:
            self.rect.x += 7
            if self.rect.right > WIDTH:
                self.rect.right = WIDTH
    def change_normal_mode(self):
        if self.boom != True:
            if time.time() - self.mode_timer >= 0.1:
                if self.imageNum == 1:
                    self.image = self.image2
                    self.imageNum = 2
                else:
                    self.image = self.image1
                    self.imageNum = 1
                self.mode_timer = time.time()
    def attack(self):
        global all_PlayerBullet
        if time.time() - self.attack_timer >= 0.2:
            bullet = PlayerBullet(self)
            all_PlayerBullet.add(bullet)
            self.attack_timer = time.time()
    def check(self):
        global all_enemys,gameover
        self.enemy = pygame.sprite.spritecollide(self,all_enemys,False,pygame.sprite.collide_mask)
        if self.enemy and self.boom == False:
                self.boom = True
                for self.i in self.enemy:
                    self.i.boom = True
        if pygame.sprite.spritecollide(self,all_EnemyBullet,True) and self.boom == False:
            self.boom = True
        if self.boom == True and time.time() - self.boom_timer >= 0.1:
            self.image = self.boomImages[self.boomImage_index]
            self.boomImage_index += 1
            self.boom_timer = time.time()
            if self.boomImage_index >= 4:
                self.boom = False
                self.boomImage_index = 0
                gameover = True


class Enemy1(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("./images/enemy1.png")
        self.rect = self.image.get_rect()
        self.rect.centerx = random.randint(30,WIDTH-30)
        self.rect.bottom = 0
        self.boom = False
        self.image_index = 0
        self.image1 = pygame.image.load("./images/enemy1_down1.png")
        self.image2 = pygame.image.load("./images/enemy1_down2.png")
        self.image3 = pygame.image.load("./images/enemy1_down3.png")
        self.image4 = pygame.image.load("./images/enemy1_down4.png")
        self.images = [self.image1,self.image2,self.image3,self.image4]
        self.boom_timer = time.time()
    def update(self):
        global score
        self.rect.y += 3
        if self.rect.top >= HEIGHT:
            all_enemys.remove(self)
        if pygame.sprite.spritecollide(self,all_PlayerBullet,False) and self.boom == False:
            self.boom = True
            score += 100
        if self.boom == True and time.time() - self.boom_timer >= 0.1:
            self.image = self.images[self.image_index]
            self.image_index += 1
            self.boom_timer = time.time()
            if self.image_index >= 4:
                self.boom = False
                all_enemys.remove(self)
class Enemy2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("./images/enemy2.png")
        self.rect = self.image.get_rect()
        self.rect.centerx = random.randint(30,WIDTH-30)
        self.rect.bottom = 0
        self.boom = False
        self.image_index = 0
        self.hp = 100
        self.image1 = pygame.image.load("./images/enemy2_down1.png")
        self.image2 = pygame.image.load("./images/enemy2_down2.png")
        self.image3 = pygame.image.load("./images/enemy2_down3.png")
        self.image4 = pygame.image.load("./images/enemy2_down4.png")
        self.images = [self.image1,self.image2,self.image3,self.image4]
        self.boom_timer = time.time()
        self.attack_timer = time.time()
    def update(self):
        global score
        self.rect.y += 3
        pygame.draw.line(screen,(30,30,30),(self.rect.topleft[0],self.rect.topleft[1]-10),(self.rect.topright[0],self.rect.topright[1]-10),3)
        if self.hp > 0 :
            if self.hp > 40:
                pygame.draw.line(screen,(0,255,0),(self.rect.topleft[0],self.rect.topleft[1]-10),(self.rect.topright[0]-(100-self.hp)*((self.rect.topright[0]-self.rect.topleft[0])/100),self.rect.topright[1]-10),3)
            else:
                pygame.draw.line(screen, (255, 0, 0), (self.rect.topleft[0], self.rect.topleft[1] - 10), (self.rect.topright[0] - (100 - self.hp) * ((self.rect.topright[0] - self.rect.topleft[0]) / 100),self.rect.topright[1] - 10), 3)
        if self.hp <= 0 and self.boom == False:
            self.boom = True
            score += 500
        if self.rect.top >= HEIGHT:
            all_enemys.remove(self)
        self.Cbullet = pygame.sprite.spritecollide(self,all_PlayerBullet,False)
        for self.i in self.Cbullet:
            all_PlayerBullet.remove(i)
            self.hp -= 5
        if self.boom == True and time.time() - self.boom_timer >= 0.1:
            self.image = self.images[self.image_index]
            self.image_index += 1
            self.boom_timer = time.time()
            if self.image_index >= 4:
                self.boom = False
                all_enemys.remove(self)
    def attack(self):
        global all_EnemyBullet
        if time.time() - self.attack_timer >= 0.2:
            self.bullet = EnemyBullet(self)
            all_EnemyBullet.add(self.bullet)
            self.attack_timer = time.time()
            print(123)
class Enemy3(pygame.sprite.Sprite):
    def __init__(self):
        global score
        pygame.sprite.Sprite.__init__(self)
        self.image1 = pygame.image.load("./images/enemy3_n1.png")
        self.image2 = pygame.image.load("./images/enemy3_n2.png")
        self.image = self.image1
        self.imageNum = 1
        self.rect = self.image.get_rect()
        self.rect.centerx = random.randint(30,WIDTH-30)
        self.rect.bottom = 0
        self.boom = False
        self.image_index = 0
        self.Bimage1 = pygame.image.load("./images/enemy3_down1.png")
        self.Bimage2 = pygame.image.load("./images/enemy3_down2.png")
        self.Bimage3 = pygame.image.load("./images/enemy3_down3.png")
        self.Bimage4 = pygame.image.load("./images/enemy3_down4.png")
        self.Bimages = [self.Bimage1,self.Bimage2,self.Bimage3,self.Bimage4]
        self.boom_timer = time.time()
        self.mode_timer = time.time()
        self.attack_timer = time.time()
        self.hp = score / 150
        self.full_hp = self.hp
    def update(self):
        global score
        self.rect.y += 3
        pygame.draw.line(screen,(30,30,30),(self.rect.topleft[0],self.rect.topleft[1]-10),(self.rect.topright[0],self.rect.topright[1]-10),3)
        if self.rect.top >= HEIGHT:
            all_enemys.remove(self)
        if self.hp > 0 :
            if self.hp > self.full_hp / 5 * 2:
                pygame.draw.line(screen,(0,255,0),(self.rect.topleft[0],self.rect.topleft[1]-10),(self.rect.topright[0]-(self.full_hp-self.hp)*((self.rect.topright[0]-self.rect.topleft[0])/self.full_hp),self.rect.topright[1]-10),3)
            else:
                pygame.draw.line(screen, (255, 0, 0), (self.rect.topleft[0], self.rect.topleft[1] - 10), (self.rect.topright[0] - (self.full_hp - self.hp) * ((self.rect.topright[0] - self.rect.topleft[0]) / self.full_hp),self.rect.topright[1] - 10), 3)
        if self.hp <= 0 and self.boom == False:
            self.boom = True
            score += 1000
        self.Cbullet = pygame.sprite.spritecollide(self,all_PlayerBullet,False)
        for self.i in self.Cbullet:
            all_PlayerBullet.remove(i)
            self.hp -= 5
        if self.boom == True and time.time() - self.boom_timer >= 0.2:
            self.image = self.Bimages[self.image_index]
            self.image_index += 1
            self.boom_timer = time.time()
            if self.image_index >= 4:
                self.boom = False
                all_enemys.remove(self)
    def change_normal_mode(self):
        if self.boom != True:
            if time.time() - self.mode_timer >= 0.1:
                if self.imageNum == 1:
                    self.image = self.image2
                    self.imageNum = 2
                else:
                    self.image = self.image1
                    self.imageNum = 1
                self.mode_timer = time.time()
    def attack(self):
        global all_EnemyBullet,boss
        if boss:
            if time.time() - self.attack_timer >= 0.5:
                self.bullet = EnemyBullet(self)
                all_EnemyBullet.add(self.bullet)
                self.attack_timer = time.time()

player = Player()
system = System()


clock = pygame.time.Clock()
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.mixer.music.play(-1)
while running:
    clock.tick(FPS)
    screen.fill((0,0,0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    system.blitBackground(screen)
    system.main_controls()
    player.draw(screen)
    all_PlayerBullet.draw(screen)
    all_EnemyBullet.draw(screen)
    all_enemys.draw(screen)
    all_enemys.update()
    system.blit_score(screen,score)
    if level == 10 and boss == False:
        warningSurface = font2.render("boss level",True,(255,0,0))
        warningRect = warningSurface.get_rect()
        warningRect.center = (240,350)
        screen.blit(warningSurface,warningRect)
        if boss_telled == False:
            boss_timer = time.time()
            boss_telled = True
        if time.time() - boss_timer >= 3:
            boss = True
    pygame.display.update()



    player.update()
    player.change_normal_mode()
    player.attack()
    player.check()
    old_level,now_level = system.set_level()
    if old_level != now_level:
        upgrade.play()
    for i in all_enemys.sprites():
        try:
            i.change_normal_mode()
            i.attack()
        except:
            pass
    all_PlayerBullet.update()
    all_EnemyBullet.update()

    auto = random.randint(1,100)
    if level == 1:
        if auto <= 90:
            system.make_enemy1()
        else:
            system.make_enemy2()
    elif level == 2:
        system.make_enemys_wait_mu = 2.5
        if auto <= 70:
            system.make_enemy1()
        else:
            system.make_enemy2()
    elif level == 3:
        system.make_enemys_wait_mu = 2
        if auto <= 50:
            system.make_enemy1()
        else:
            system.make_enemy2()
    elif level == 4:
        system.make_enemys_wait_mu = 1.5
        if auto <= 45:
            system.make_enemy1()
        elif auto <= 90:
            system.make_enemy2()
        else:
            system.make_enemy3()
    elif level == 5:
        system.make_enemys_wait_mu = 1
        if auto <= 33:
            system.make_enemy1()
        elif auto <= 66:
            system.make_enemy2()
        else:
            system.make_enemy3()
    else:
        system.make_enemys_wait_mu = 1 - level * 0.1 if system.make_enemys_wait_mu > 0.3 else system.make_enemys_wait_mu
        if auto <= 33:
            system.make_enemy1()
        elif auto <= 66:
            system.make_enemy2()
        else:
            system.make_enemy3()

