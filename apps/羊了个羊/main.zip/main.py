# Author : Owen

import pygame
import random

pygame.init()
pygame.mixer.music.load("music/bgm.mp3")
screen = pygame.display.set_mode((600, 800))
pygame.display.set_caption("羊了个羊")

icons = [pygame.transform.scale(pygame.image.load("images/tile{}.png".format(i)), (60, 66)) for i in range(1, 11)]
icons_ = [pygame.transform.scale(pygame.image.load("images/tile{}.png".format(i)), (60, 66)) for i in range(1, 11)]
bg = pygame.image.load("images/back.png")
restart = pygame.image.load("images/restart.png")
restart_rect = restart.get_rect()
restart_rect.center = (300, 740)
blocks = pygame.sprite.Group()
map = []
MousePressed = False
pos = (0, 0)
dock = []


def create_map_1(width=7, height=6):
    for h in range(height):
        map.append([])
        for i in range(width - h):
            map[h].append([])
            for j in range(width - h):
                map[h][i].append(random.randint(0, 9))
            # for num in range(0, 11):
            #     layer = []
            #     for j in map[h]:
            #         for k in j:
            #             layer.append(k)
            #     print(layer.count(num))


def create_map_o(width=7, height=6):
    num = 0
    for h in range(height):
        map.append([])
        for i in range(width - h):
            map[h].append([])
            for j in range(width - h):
                if not map[h][i][j] == None:
                    sprite = blocks.sprites()[num]
                    icon = random.randint(0, 9)
                    map[h][i][j] = icon
                    sprite.refresh_icon(icon)
                    num += 1


def make_blocks():
    x = 87
    y = 30
    # numi = 0
    # numj = 0
    for h in map:
        y = 30 + 33 * map.index(h)
        for i in h:
            x = 87 + 30 * map.index(h)
            for j in i:
                block = Block(j, (x, y), map.index(h))
                blocks.add(block)
                x += 60
            # numj += 1
            y += 66
        # numi += 1
        # numj = 0


def check_dock():
    if dock:
        tempData = dock[0].type
        combo = 1
        for i in dock[1:len(dock)]:
            if i.type != tempData:
                tempData = i.type
                combo = 1
            else:
                combo += 1
                if combo >= 3:
                    indexOfi = dock.index(i)
                    i.kill()
                    dock[indexOfi - 1].kill()
                    dock[indexOfi - 2].kill()
                    del dock[indexOfi], dock[indexOfi - 1], dock[indexOfi - 2]
    if len(dock) >= 7:
        pygame.quit()
        exit()
    index = 0
    for i in dock:
        i.indexInDock = index
        index += 1


class Block(pygame.sprite.Sprite):
    def __init__(self, index, pos, height):
        pygame.sprite.Sprite.__init__(self)
        self.type = index
        self.image_normal = icons[index]
        self.image_disable = icons_[index]
        self.mask = pygame.surface.Surface((60, 66)).convert_alpha()
        self.mask.fill((0, 0, 0, 20))
        self.image_disable.blit(self.mask, (0, 0))
        self.image = self.image_normal
        self.rect = self.image.get_rect()
        self.rect.topleft = pos
        # self.PosXim = PosXim
        # self.PosYim = PosYim
        self.clicked = False
        self.height = height

    def update(self, pos):
        global map, dock
        self.image = self.image_normal
        for sprite in blocks.sprites():
            if sprite.rect.colliderect(self.rect):
                if sprite.height > self.height:
                    self.image = self.image_disable
                    break
        if MousePressed:
            if not self.clicked:
                for sprite in blocks.sprites():
                    if sprite.rect.colliderect(self.rect):
                        if sprite.height > self.height:
                            break
                else:
                    if self.rect.collidepoint(pos):

                        for i in dock:
                            if i.type == self.type:
                                self.indexAfter = dock.index(i)
                                dock.insert(self.indexAfter + 1, self)
                                self.indexInDock = self.indexAfter + 1
                                break
                        else:
                            self.indexInDock = len(dock)
                            dock.append(self)

                        self.clicked = True
                        # map[self.PosYim][self.PosXim] = None
            else:
                self.rect.topleft = (90 + self.indexInDock * 60, 565)

    def refresh_icon(self, index):
        if self.clicked == False:
            self.image_normal = icons[index]
            self.image_disable = icons_[index]
            self.image = self.image_normal
            self.type = index


create_map_1()
make_blocks()
pygame.mixer.music.play(-1)

while True:
    screen.fill((255, 255, 255))
    screen.blit(bg, (0, 0))
    check_dock()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.MOUSEMOTION:
            pos = event.pos
        elif event.type == pygame.MOUSEBUTTONDOWN:
            MousePressed = True
            if restart_rect.collidepoint(pos):
                create_map_o()
        elif event.type == pygame.MOUSEBUTTONUP:
            MousePressed = False
    blocks.draw(screen)
    screen.blit(restart, restart_rect)
    for sprite in blocks.sprites():
        sprite.update(pos)
    pygame.display.update()
    # for i in dock:
    #     print(i.type, end=",")
    # print()
